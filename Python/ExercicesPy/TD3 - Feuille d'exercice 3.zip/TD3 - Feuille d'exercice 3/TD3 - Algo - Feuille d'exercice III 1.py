# 1. Dé ASCII

import random

faceDuDe=random.randint(1,6)

if faceDuDe==1:
    print("\n\t0\n")

if faceDuDe==2:
    print("0\n\n\t\t0")

if faceDuDe==3:
    print("0\n\t0\n\t\t0")

if faceDuDe==4:
    print("0\t\t0\n\n0\t\t0")

if faceDuDe==5:
    print("0\t\t0\n\t0\n0\t\t0")

if faceDuDe==6:
    print("0\t0\n0\t0\n0\t0")