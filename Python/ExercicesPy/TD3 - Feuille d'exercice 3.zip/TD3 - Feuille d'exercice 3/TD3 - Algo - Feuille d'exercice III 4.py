#4. Pas d'une boucle

for i in range(int(input("Borne de départ : ")),int(input("Borne d'arrivée : "))+1,int(input("Pas d'incrément : "))):
    print(i)

